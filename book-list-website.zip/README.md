# Book List Website 📚

This is a simple HTML and CSS project that displays a list of favorite books.

## 📄 Features
- Home page showing a list of 3 books with title, author, and short description
- About page describing the website
- Simple and clean design

## 📁 File Structure
```
book-list-website/
├── index.html
├── about.html
├── style.css
└── README.md
```

## 🚀 How to Use
1. Download the ZIP file.
2. Extract it and open `index.html` in your browser.
3. Edit the HTML to add your own books if you like!

## 🛠️ Tech Used
- HTML5
- CSS3

---
Made with ❤️ by a book lover.